package com.wvcteam.movie4.ui.movie_details

import androidx.lifecycle.LiveData
import com.wvcteam.movie4.data.api.MovieDBInterface
import com.wvcteam.movie4.data.repository.MovieDetailsNetworkDataSoucer
import com.wvcteam.movie4.data.repository.NetworkState
import com.wvcteam.movie4.data.value_obj.MovieDetails
import io.reactivex.disposables.CompositeDisposable

class MovieDetailsRepository(private val apiService : MovieDBInterface) {

    lateinit var movieDetailsNetworkDataSource: MovieDetailsNetworkDataSoucer


    fun fetchSingleMovieDetails (compositeDisposable: CompositeDisposable, movieId: Int) : LiveData<MovieDetails> {

        movieDetailsNetworkDataSource = MovieDetailsNetworkDataSoucer(apiService,compositeDisposable)
        movieDetailsNetworkDataSource.fetchMovieDetails(movieId)

        return movieDetailsNetworkDataSource.downloadedMovieResponse

    }

    fun getMovieDetailsNetworkState(): LiveData<NetworkState> {
        return movieDetailsNetworkDataSource.networkState
    }

}