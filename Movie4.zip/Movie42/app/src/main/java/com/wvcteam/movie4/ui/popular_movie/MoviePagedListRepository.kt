package com.wvcteam.movie4.ui.popular_movie

import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import androidx.paging.LivePagedListBuilder
import androidx.paging.PagedList
import com.wvcteam.movie4.data.api.MovieDBInterface
import com.wvcteam.movie4.data.api.POST_PER_PAGE
import com.wvcteam.movie4.data.repository.MovieDataSource
import com.wvcteam.movie4.data.repository.MovieDataSourceFactory
import com.wvcteam.movie4.data.repository.NetworkState
import com.wvcteam.movie4.data.value_obj.Movie
import io.reactivex.disposables.CompositeDisposable

class MoviePagedListRepository(private val apiService : MovieDBInterface) {
    lateinit var moviePagedList: LiveData<PagedList<Movie>>
    lateinit var moviesDataSourceFactory: MovieDataSourceFactory

    fun fetchLiveMoviePagedList (compositeDisposable: CompositeDisposable) : LiveData<PagedList<Movie>> {
        moviesDataSourceFactory = MovieDataSourceFactory(apiService, compositeDisposable)
        val config = PagedList.Config.Builder()
            .setEnablePlaceholders(false)
            .setPageSize(POST_PER_PAGE)
            .build()

        moviePagedList = LivePagedListBuilder(moviesDataSourceFactory, config).build()

        return moviePagedList
    }

    fun getNetworkState(): LiveData<NetworkState> {
        return Transformations.switchMap<MovieDataSource, NetworkState>(
            moviesDataSourceFactory.moviesLiveDataSource, MovieDataSource::networkState)
    }


}