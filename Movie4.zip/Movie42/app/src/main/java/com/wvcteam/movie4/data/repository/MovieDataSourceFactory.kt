package com.wvcteam.movie4.data.repository

import androidx.lifecycle.MutableLiveData
import com.wvcteam.movie4.data.value_obj.Movie
import androidx.paging.DataSource
import com.wvcteam.movie4.data.api.MovieDBInterface
import io.reactivex.disposables.CompositeDisposable

class MovieDataSourceFactory (private val apiService : MovieDBInterface, private val compositeDisposable: CompositeDisposable)
    : DataSource.Factory<Int,Movie> (){

    val moviesLiveDataSource =  MutableLiveData<MovieDataSource>()

    override fun create(): DataSource<Int, Movie> {

        val movieDataSource = MovieDataSource(apiService,compositeDisposable)


        moviesLiveDataSource.postValue(movieDataSource)
        return movieDataSource
    }


}